# ROADMAP — SMART TOKO AI

Aturan kerja: satu tahap dikerjakan sampai selesai dan diuji, lalu menunggu persetujuan pemilik sebelum tahap berikutnya.

| Status | Arti |
|---|---|
| [ ] | belum dikerjakan |
| [~] | sedang dikerjakan |
| [x] | selesai dan sudah diuji |

## Tahap 1 — Prototipe kasir (data lokal)
- [ ] Struktur proyek, build, dan tes dasar berjalan
- [ ] Dashboard
- [ ] Katalog produk dan kategori (buah, frozen food)
- [ ] Harga beli, harga jual, satuan kg, gram, pcs, pack, dus
- [ ] Keranjang dan transaksi kasir
- [ ] Pengurangan stok lewat catatan pergerakan stok
- [ ] Riwayat transaksi
- [ ] Ringkasan omzet, HPP, dan laba kotor
- [ ] Penyimpanan lokal (IndexedDB)

## Tahap 2 — Kasir offline
- [ ] PWA dan Service Worker
- [ ] Antrean sinkronisasi (outbox)
- [ ] Supabase: skema, login, Row Level Security
- [ ] ID unik dan pencegahan transaksi ganda
- [ ] Indikator status sinkronisasi
- [ ] Penanganan gagal sinkron dan konflik

## Tahap 3 — Stok dan pembelian
- [ ] Barang masuk dan keluar, konversi satuan
- [ ] Supplier, pembelian, harga modal
- [ ] Stok minimum dan rekomendasi restok
- [ ] Batch dan tanggal kedaluwarsa
- [ ] Busuk, susut, retur, barang rusak

## Tahap 4 — Keuangan
- [ ] Kas masuk dan keluar, pemasukan dan pengeluaran
- [ ] Utang supplier dan piutang pelanggan
- [ ] HPP, laba kotor, biaya operasional, estimasi laba bersih
- [ ] Laporan harian, mingguan, bulanan
- [ ] Ekspor Excel atau CSV
- [ ] Audit transaksi dan penyesuaian stok

## Tahap 5 — Karyawan
- [ ] Akun individual dan hak akses
- [ ] Absensi dan jadwal
- [ ] Gaji, lembur, bonus, potongan, kasbon
- [ ] Riwayat aktivitas pengguna

## Tahap 6 — Multi-cabang
- [ ] Identitas cabang, stok dan transaksi terpisah
- [ ] Laporan gabungan
- [ ] Transfer stok antar-cabang
- [ ] Konflik saat banyak perangkat offline
- [ ] Pembatasan akses per cabang dan peran

## Tahap 7 — AI Agent
- [ ] Analisis penjualan dan laba
- [ ] Rekomendasi restok, barang lambat terjual
- [ ] Analisis kerusakan dan kedaluwarsa
- [ ] Draft pesanan supplier
- [ ] Laporan berkala
- [ ] Semua tindakan penting menunggu persetujuan pemilik

## Sebelum dipakai untuk transaksi asli
- [ ] Backup dan prosedur pemulihan diuji
- [ ] Batas paket gratis diperiksa ulang
- [ ] Kredensial dan RLS ditinjau
