# ARCHITECTURE — SMART TOKO AI

Aplikasi kasir dan keuangan toko buah dan frozen food. Satu cabang saat ini, dirancang siap multi-cabang.

## 1. Stack

| Lapisan | Pilihan | Catatan |
|---|---|---|
| Frontend | React + TypeScript + Vite | Dibuild di cloud, tidak perlu IDE di laptop |
| PWA | Service Worker (vite-plugin-pwa) | Aplikasi bisa dibuka tanpa internet setelah dipasang |
| Data lokal | IndexedDB lewat Dexie | Sumber data utama saat offline |
| Database pusat | Supabase PostgreSQL | Mulai dipakai di Tahap 2; Tahap 1 hanya lokal |
| Hosting | Cloudflare Pages | Gratis untuk situs statis |
| Kode | GitHub | Repositori privat |

## 2. Prinsip desain data

1. **Uang = bilangan bulat rupiah.** Tidak memakai desimal.
2. **Kuantitas = bilangan bulat dalam satuan dasar** (gram untuk berat, pcs untuk hitungan). Konversi kg, pack, dan dus dilakukan saat tampil dan saat input, bukan saat simpan.
3. **Semua ID adalah UUID yang dibuat di perangkat.** Ini mencegah tabrakan ID dan transaksi ganda saat sinkronisasi.
4. **`branch_id` ada di semua tabel sejak Tahap 1**, walau cabang hanya satu.
5. **Stok tidak disimpan sebagai angka yang ditimpa.** Stok = jumlah seluruh baris `stock_movements` per produk dan cabang. Setiap perubahan stok adalah satu baris baru yang tidak diedit.
6. **Transaksi penjualan hanya bertambah (append-only).** Pembatalan dicatat sebagai transaksi pembalik, bukan penghapusan.
7. **Soft delete** untuk data master (produk, kategori): ditandai nonaktif, tidak dihapus.

## 3. Tabel inti (Tahap 1)

- `branches` (id, nama)
- `categories` (id, branch_id, nama, jenis: buah | frozen)
- `products` (id, branch_id, category_id, nama, satuan_dasar, harga_beli, harga_jual, stok_minimum, aktif)
- `sales` (id, branch_id, nomor_struk, waktu, total, metode_bayar, status)
- `sale_items` (id, sale_id, product_id, qty_dasar, harga_jual_saat_itu, harga_beli_saat_itu)
- `stock_movements` (id, branch_id, product_id, qty_dasar, jenis: awal | jual | batal | masuk | susut | koreksi, ref_id, waktu)

`harga_beli_saat_itu` disimpan di setiap item penjualan agar laba historis tidak berubah ketika harga modal berubah.

## 4. Definisi keuangan (dipakai mulai Tahap 1)

- **Omzet** = total penjualan.
- **Pembayaran diterima** = uang yang benar-benar masuk (bisa lebih kecil dari omzet jika ada piutang).
- **HPP** = harga beli barang yang terjual.
- **Laba kotor** = omzet − HPP.
- **Biaya operasional** = sewa, listrik, gaji, dan sejenisnya. Pembelian stok **bukan** biaya operasional.

## 5. Rencana sinkronisasi (Tahap 2)

- Setiap perubahan ditulis ke tabel lokal dan ke antrean `outbox`.
- Saat online, `outbox` dikirim ke Supabase berurutan. Server menolak ID yang sudah ada, sehingga pengiriman ulang aman (idempoten).
- Waktu urutan memakai waktu server; waktu perangkat hanya dicatat sebagai informasi.
- Data master (harga, nama): versi terbaru menang, dengan nomor versi dan catatan perubahan.
- Transaksi dan pergerakan stok tidak pernah ditimpa, hanya ditambah.

## 6. Risiko offline yang diketahui

| Risiko | Penanganan |
|---|---|
| Dua perangkat offline menjual stok yang sama | Stok boleh sementara minus, ditandai merah, dan dilaporkan saat sinkronisasi |
| Browser menghapus IndexedDB | Minta penyimpanan persisten; sediakan ekspor cadangan manual |
| Jam perangkat salah | Urutan pakai waktu server |
| Service Worker menyajikan versi lama | Tampilkan notifikasi "versi baru tersedia" |
| Sinkronisasi gagal di tengah jalan | Outbox dicoba ulang; kegagalan ditampilkan, tidak disembunyikan |
| Stok semua cabang tampak real-time padahal ada perangkat belum sinkron | Tampilkan waktu sinkronisasi terakhir per perangkat |

## 7. Keamanan (Tahap 2 dan seterusnya)

- Row Level Security di Supabase, berdasarkan peran dan `branch_id`.
- Hanya anon key di frontend. Service-role key tidak boleh ada di kode atau repositori.
- Kredensial lewat variabel lingkungan Cloudflare dan Supabase.
- Audit log untuk perubahan penting.
- Backup dan prosedur pemulihan harus selesai sebelum dipakai untuk transaksi asli.

## 8. Biaya

Target Rp0 untuk prototipe. Batas paket gratis Supabase dan Cloudflare diperiksa ulang sebelum deployment, termasuk risiko proyek dijeda karena tidak aktif dan tidak adanya jaminan backup otomatis. Tidak ada peralihan ke layanan berbayar tanpa persetujuan pemilik.
