# TEST PLAN — SMART TOKO AI

Aturan: fitur baru dianggap selesai hanya setelah tesnya dijalankan dan lulus. Hasil tes dicatat, bukan diasumsikan.

## Jenis tes
- **Unit**: fungsi hitung (konversi satuan, total, HPP, laba) memakai Vitest.
- **Komponen/alur**: layar kasir dan katalog memakai Testing Library.
- **End-to-end**: alur lengkap di browser memakai Playwright.
- **Manual**: dicoba pemilik di Android dan Windows.

## Tahap 1

### Perhitungan
| Kasus | Hasil yang diharapkan |
|---|---|
| 1,5 kg dibeli, harga Rp30.000/kg | total Rp45.000 |
| 250 gram dari stok 2 kg | stok menjadi 1.750 gram |
| 1 dus berisi 12 pack, jual 3 pack | stok berkurang 3 pack, sisa 9 |
| Harga beli naik setelah penjualan | laba penjualan lama tidak berubah |
| Semua nilai uang dan kuantitas | bilangan bulat, tanpa selisih pembulatan |

### Kasir dan stok
- Tambah, ubah, hapus item di keranjang, total ikut berubah.
- Transaksi tersimpan, stok berkurang lewat satu baris `stock_movements` per item.
- Stok tidak bisa menjadi minus di Tahap 1 (ditolak dengan pesan jelas).
- Pembatalan transaksi membuat transaksi pembalik dan mengembalikan stok.
- Keranjang kosong tidak bisa dibayar.
- Klik bayar dua kali tidak membuat transaksi ganda.

### Data lokal
- Data bertahan setelah halaman dimuat ulang.
- Riwayat dan omzet sama dengan jumlah transaksi yang tersimpan.
- Omzet harian memakai batas tanggal zona waktu WIB.

### Build
- `npm run build` berhasil tanpa error TypeScript.
- `npm run lint` dan `npm test` lulus.

## Tahap 2 (disiapkan)
- Matikan jaringan, buat transaksi, buka ulang aplikasi: data masih ada.
- Nyalakan jaringan: outbox terkirim, status berubah menjadi tersinkron.
- Kirim ulang paket yang sama: tidak ada transaksi ganda.
- Dua perangkat menjual produk yang sama saat offline: keduanya tersimpan, stok minus ditandai.
- Putuskan koneksi di tengah sinkronisasi: antrean dilanjutkan tanpa kehilangan data.
- Pengguna cabang A tidak bisa membaca data cabang B (uji RLS).

## Pencatatan hasil
Setiap tahap diakhiri dengan tabel: tes, status (lulus/gagal/belum diuji), dan catatan.
